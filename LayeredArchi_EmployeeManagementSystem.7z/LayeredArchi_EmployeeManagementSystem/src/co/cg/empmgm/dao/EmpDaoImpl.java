package co.cg.empmgm.dao;
import java.sql.*;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.util.DBUtil;

public class EmpDaoImpl implements EmployeeDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger empLogger=null;
	
	public EmpDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		empLogger=Logger.getLogger("EmpDaoImpl.class");
	}
	@Override
	public int addEmp(Employee emp) throws EmployeeException 
	{
		int dataAdded;
		String insertQry="INSERT INTO "
				+ " emp_142958(emp_id,emp_name,emp_sal) VALUES(?, ?, ?)";
		try 
		{
			con=DBUtil.getCon();
			//System.out.println( con+"******************************");
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generateEmpId());
			pst.setString(2, emp.getEmpName());
			pst.setFloat(3, emp.getEmpSal());
			dataAdded=pst.executeUpdate();
			empLogger.log(Level.INFO, "Emp Inserted: "+emp);
			/*dataAdded=1 after execution 
			 * bcoz it depends on number of records adding
			 * and that result in case of insert query is 1
			 */
		} 
		catch (Exception e) 
		{
			empLogger.error("This is Exception:"+e.getMessage());
			throw new EmployeeException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				empLogger.error("This is Exception:"+e.getMessage());;
				throw new EmployeeException(e.getMessage());	
			}
		}
		return dataAdded;
	}

	/************************************************/
	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException
	{
		ArrayList<Employee> empList= new ArrayList<Employee>();
		String selectQry="SELECT * FROM emp_142958" ;
		Employee ee=null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				ee=new Employee(rs.getInt("emp_id"),
						rs.getString("emp_name"),
						rs.getFloat("emp_sal"));
				empList.add(ee);
			}
		} 
		catch (Exception e) 
		{
			empLogger.error("This is Exception:"+e.getMessage());;
			throw new EmployeeException(e.getMessage());
		} 
		finally
		{
			try
			{
				con.close();
				st.close();
				rs.close();
			}
			catch(Exception e)
			{
				empLogger.error("This is Exception:"+e.getMessage());;
				throw new EmployeeException(e.getMessage());
			}
		}
		return empList;
	}

	@Override
	/*we are actually getting SQLException here but as this method throw EmployeeException 
	in Interface so here also we have to throw EmployeeException*/
	public int generateEmpId() throws EmployeeException 
	{
		///System.out.println("***********************************");
		int generatedVal;
		String qry="SELECT emp_seq.NEXTVAL "
				+ " FROM DUAL";
		//System.out.println("********@***************************");
		try 
		{
			con=DBUtil.getCon();
			System.out.println(con);
			st=con.createStatement();
			rs=st.executeQuery(qry);
		//	System.out.println("***********************************"+rs);
			rs.next();
			
			generatedVal=rs.getInt(1);

		} 
		catch (Exception e) 
		{
			empLogger.error("This is Exception:"+e.getMessage());;
			throw new EmployeeException(e.getMessage());		
		} 
		finally//reqd to closing all connections which are opened like con
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (SQLException e) 
			{	
				empLogger.error("This is Exception:"+e.getMessage());;
				throw new EmployeeException(e.getMessage());		
			}

		}
		return generatedVal;
	}

}
