package com.cg.empmgm.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;

import co.cg.empmgm.dao.EmpDaoImpl;
import co.cg.empmgm.dao.EmployeeDao;

public class EmpDaoImplTest 
{
	static EmployeeDao empDao=null;
	static Employee emp=null;
	@BeforeClass
	public static void beforeClass() throws EmployeeException
	{
		empDao=new EmpDaoImpl();
		emp=new Employee(empDao.generateEmpId(),"AAA",1000);
	}
	@Test
	public void testAddEmp() throws EmployeeException
	{
		
		Assert.assertEquals(1, empDao.addEmp(emp));
	}
	@Test(expected=Exception.class)
	public void testAddEmp2() throws EmployeeException
	{
		Assert.assertEquals(1, empDao.addEmp(emp));
	}
	@Test
	public void testAddEmp3() throws EmployeeException
	{
		Assert.assertNotNull(empDao.getAllEmp());
	}


}
