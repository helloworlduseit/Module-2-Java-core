package com.cg.empmgm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.service.EmpService;
import com.cg.empmgm.service.EmpServiceImpl;

public class EmployeeClient {
	static Scanner sc=null;
	static EmpService empser=null;
	public static void main(String[] args) 
	{
		empser= new EmpServiceImpl();
		sc= new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What Do U want to do ?");

System.out.println("1) Add Emp\n"
					+ "2) Fetch All emp\n"
					+ "3) Delete Emp\n"
					+ "4) Update Emp\n"
					+ "5) Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
			{
				insertEmp();
				break;
			}
			case 2:
			{
				fetchAllEmp();
				break;
			}
			case 3:
			{
				delEmp();
				break;
			}
			case 4:
			{
				updateEmp();
				break;
			}
			default:System.exit(0);

			}
		}

	}
	/*********************************Main Ends*******************************/
	public static void insertEmp()
	{
		System.out.println("Enter Emp Name: ");
		String nm=sc.next();
		float esl=0.0F;
		Employee ee;
		try
		{
			if (empser.validateName(nm))
			{
				System.out.println("Enter Salary: ");
				esl=sc.nextFloat();
				ee=new Employee();
				ee.setEmpName(nm);
				ee.setEmpSal(esl);
				int dataAdded=empser.addEmp(ee);
				if(dataAdded==1)
				{
					System.out.println("Emp Data Added.");
				}
				else{
					System.out.println("May be Some Exception occus while Addition");
				}
			}
		} 
		catch (EmployeeException e) 
		{

			e.printStackTrace();
		}
	}
	/*************************************************/
	public static void fetchAllEmp()
	{
		try
		{
			ArrayList<Employee> empList=empser.getAllEmp();
			for(Employee ee:empList)
			{
			System.out.println(ee);
			}
		} 
		catch (EmployeeException e)
		{
			System.out.println("Some Exception occurs while fetching data");
			e.printStackTrace();
		}
		

	}
	/********************************************************/
	public static void delEmp()
	{

	}
	/*******************************************************/
	public static void updateEmp()
	{

	}
	/*****************************************************/

}
