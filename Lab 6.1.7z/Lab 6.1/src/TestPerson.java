
public class TestPerson {

	public static void main(String[] args) {
		String fname="null";
		Person person = new Person(fname, "Bharathi", 'F');
		try
		{
			if(person.getFirstName().compareTo("null")==0|| person.getLastName().compareTo("null")==0){
				throw new NoDataAvailableException("Please check entered data");
			}
			else{
				System.out.println("Person Details:");
				System.out.println("------------------------------");
				System.out.println("First Name: "+person.getFirstName());
				System.out.println("Last Name: "+person.getLastName());
				System.out.println("Gender: "+person.getGender());
			}

		}
		catch(NoDataAvailableException nn)
		{
			System.out.println("Plese entered deatils........");
			System.out.println(nn);
		}
		finally{
			System.out.println(" ");
		}

	}

}

