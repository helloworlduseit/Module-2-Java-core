import java.sql.*;
import java.util.Scanner;


public class TestEmpData2Demo 
{
	public static void main(String[] args)
	{
		Connection conn=null;//Get Connection Object
		PreparedStatement pst=null;//Get Statement Object
		Scanner sc= new Scanner(System.in);
		
		
		ResultSet rs=null;//declaring result set is nothing by record which can store return statement result
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//this line throw ClassNotFoundException.....This is optional line
			
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe", "System" , "Capgemini123");
			//creation of Connection Object
			
			System.out.println("Enter Id : ");
			int empId=sc.nextInt();
			System.out.println("Enter Name: ");
			String empName= sc.next();
			System.out.println("Enter Salary : ");
			float empSal=sc.nextFloat();
			
			
			String insertQuery="INSERT INTO Emp_142958(emp_id,emp_name,emp_sal) "
					+ "VALUES(?,?,?)";
			
			//for execute Update Statement
			pst=conn.prepareStatement(insertQuery);//creation of Statement object
			pst.setInt(1, empId);
			pst.setString(2, empName);
			pst.setFloat(3, empSal);
			int dataAdded=pst.executeUpdate();
			System.out.println("Data is Added..........");
	
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
