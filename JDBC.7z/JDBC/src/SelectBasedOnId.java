import java.sql.*;
import java.util.Scanner;
public class SelectBasedOnId 
{
	public static void main(String[] args)
	{

		Connection conn=null;//Get Connection Object
		PreparedStatement pst=null;
		Scanner sc= new Scanner(System.in);
		ResultSet rs=null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe", "System" , "Capgemini123");
			System.out.println("Enter Id of Employees whose deatil to be Displayed:");
			int empId=sc.nextInt();
			String sqlQry = "SELECT * FROM Emp_142958 WHERE emp_id=?" ;
			pst=conn.prepareStatement(sqlQry);
			pst.setInt(1, empId);
			rs=pst.executeQuery();
			System.out.println("Id\tName\tSalary");
			rs.next();
			System.out.println(rs.getInt("emp_id")+
					"\t"+rs.getString("emp_name")+
					"\t"+rs.getInt("emp_sal"));

		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
