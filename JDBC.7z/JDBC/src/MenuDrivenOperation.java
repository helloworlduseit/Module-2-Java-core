import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class MenuDrivenOperation 
{
	public static void main(String[] args) 
	{
		Connection conn=null;
		PreparedStatement pst=null;
		Scanner sc= new Scanner(System.in);
		ResultSet rs=null;
		System.out.println(" 1 . Select Based on EmpId"
				+ "\n 2. Delete based on EmpId"
				+ "\n 3. Insert No Of Records"
				+ "\n 4. Update the Salary"
				+ "\n 5. Display All Table ");
		System.out.println("Enter Your Choice :");
		int choice=sc.nextInt();
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe", "System" , "Capgemini123");

			switch(choice)
			{
			case 1:
			{
				System.out.println("Enter Id of Employees whose deatil to be Displayed:");
				int empId=sc.nextInt();
				String sqlQry = "SELECT * FROM Emp_142958 WHERE emp_id=?" ;
				pst=conn.prepareStatement(sqlQry);
				pst.setInt(1, empId);
				rs=pst.executeQuery();
				System.out.println("Id\tName\tSalary");
				rs.next();
				System.out.println(rs.getInt("emp_id")+
						"\t"+rs.getString("emp_name")+
						"\t"+rs.getInt("emp_sal"));
				break;
			}
			case 2:
			{
				System.out.println("Enter Id of Employees whose deatil to be deleted:");
				int empId=sc.nextInt();			
				String insertQuery="DELETE FROM Emp_142958 WHERE emp_id=?";
				pst=conn.prepareStatement(insertQuery);
				pst.setInt(1, empId);
				int dataDeleted=pst.executeUpdate();
				System.out.println("Data is deleted..........");
				break;
			}
			case 3:
			{
				String insertQuery="INSERT INTO Emp_142958(emp_id,emp_name,emp_sal) "
						+ "VALUES(?,?,?)";

				pst=conn.prepareStatement(insertQuery);
				System.out.println("Enter no of Employees:");
				int count = sc.nextInt();
				for(int i=0;i<count;i++)
				{
					System.out.println("Enter Id : ");
					int empId=sc.nextInt();
					System.out.println("Enter Name: ");
					String empName= sc.next();
					System.out.println("Enter Salary : ");
					float empSal=sc.nextFloat();
					pst.setInt(1, empId);
					pst.setString(2, empName);
					pst.setFloat(3, empSal);
					int dataAdded=pst.executeUpdate();

				}
				System.out.println("Data is Added..........");
				break;
			}
			case 4:
			{
				String updateQuery="UPDATE Emp_142958 SET emp_sal= emp_sal+10000 "
						+ "WHERE emp_sal<20000";
				pst=conn.prepareStatement(updateQuery);
				int dataDeleted=pst.executeUpdate();
				System.out.println("Salary is Updated..........");
				break;
			}
			case 5:
			{
				String sqlQry = "SELECT * FROM Emp_142958" ;
				pst=conn.prepareStatement(sqlQry);
				rs=pst.executeQuery();
				System.out.println("Id\tName\tSalary");
				while(rs.next())
				{
				System.out.println(rs.getInt("emp_id")+
						"\t"+rs.getString("emp_name")+
						"\t"+rs.getInt("emp_sal"));		
				}
				break;
			}
			default:
			{
				System.out.println("You have entered Wrong Choice");
				break;
			}
			}
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}

	}

}
