import java.sql.*;

/*PERSISTENCY--->PERMANETLY STORING SOMETHING(OBJECTS)
 * JDBC-->having Database Drivers bocoz of that java can be use as frontend
 * and oracle as backend.
 */
public class TestEmpSelectDemo 
{
	public static void main(String[] args)
	{
		//oracle database selected Type-4
		//Load oracle type4 driver in memory
		Connection conn=null;//Get Connection Object
		Statement st=null;//Get Statement Object
		
		ResultSet rs=null;//declaring result set is nothing by record which can store return statement result
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//this line throw ClassNotFoundException.....This is optional line
			
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe", "System" , "Capgemini123");
			//creation of Connection Object
			
			st=conn.createStatement();//creation of Statement object
			
			
			String sqlQry = "SELECT emp_id,emp_name,emp_sal FROM Emp_142958";
			rs=st.executeQuery(sqlQry);
			
			//printing result from record(rs)
			System.out.println("Id\tName\tSalary");
			while(rs.next())
			{
				//IN jdbc, all Getter functions are present in ResultsetMetaDta Interface
			System.out.println(rs.getInt("emp_id")+
										"\t"+rs.getString("emp_name")+
										"\t"+rs.getInt("emp_sal"));
			}
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
