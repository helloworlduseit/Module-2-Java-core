import java.sql.*;
import java.util.Scanner;


public class TestDeleteQuery 
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		Connection conn=null;//Get Connection Object
		PreparedStatement pst=null;//Get Statement Object
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//this line throw ClassNotFoundException.....This is optional line
			
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe", "System" , "Capgemini123");
			//creation of Connection Object
			
			System.out.println("Enter Id of Employees whose deatil to be deleted:");
			int empId=sc.nextInt();			
			String insertQuery="DELETE FROM Emp_142958 WHERE emp_id=?";
			pst=conn.prepareStatement(insertQuery);
			pst.setInt(1, empId);
			
			int dataDeleted=pst.executeUpdate();
			
			System.out.println("Data is Updated..........");
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
