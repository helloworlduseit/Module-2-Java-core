
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;

public class TestEmpAddDemo 
{
	public static void main(String[] args)
	{
		//oracle database selected Type-4
		//Load oracle type4 driver in memory
		Connection conn=null;//Get Connection Object
		Statement st=null;//Get Statement Object
		
		ResultSet rs=null;//declaring result set is nothing by record which can store return statement result
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//this line throw ClassNotFoundException.....This is optional line
			
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe", "System" , "Capgemini123");
			//creation of Connection Object
			
			String insertQuery="INSERT INTO Emp_142958(emp_id,emp_name,emp_sal) "
					+ "VALUES(66,'Kavita',80000)";
			
			//for execute Update Statement
			st=conn.createStatement();//creation of Statement object
			int data=st.executeUpdate(insertQuery);
			System.out.println("Data Inserted in Table");
	
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
