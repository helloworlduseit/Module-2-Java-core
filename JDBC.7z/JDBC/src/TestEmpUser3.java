import java.sql.*;
import java.util.Scanner;


public class TestEmpUser3 
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter No of Employees:");
		int count=sc.nextInt();
		Connection conn=null;//Get Connection Object
		PreparedStatement pst=null;//Get Statement Object
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//this line throw ClassNotFoundException.....This is optional line

			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe", "System" , "Capgemini123");
			//creation of Connection Object

			String insertQuery="INSERT INTO Emp_142958(emp_id,emp_name,emp_sal) "
					+ "VALUES(?,?,?)";

			pst=conn.prepareStatement(insertQuery);

			for(int i=0;i<count;i++)
			{
				System.out.println("Enter Id : ");
				int empId=sc.nextInt();
				System.out.println("Enter Name: ");
				String empName= sc.next();
				System.out.println("Enter Salary : ");
				float empSal=sc.nextFloat();
				pst.setInt(1, empId);
				pst.setString(2, empName);
				pst.setFloat(3, empSal);
				int dataAdded=pst.executeUpdate();

			}
			System.out.println("Data is Added..........");
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
