
public class SavingsAcc extends Account{

    private final double minBalance = 500;
    
    
    public SavingsAcc() {
        super();
    }


    public SavingsAcc(Person accHolder, long accNumber, double balance) {
        super(accHolder, accNumber, balance);
        
    }

    @Override
    public void withdraw(double amount) {
        
        if((getBalance() - amount)>500)
            super.withdraw(amount);
        else System.out.println("Widthdrawal not possible as after withdrawal min balance of 500 will not be maintained");
    }
    
}
