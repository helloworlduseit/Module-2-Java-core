
public class TestAccount {

    public static void main(String[] args) {
        Person smith = new Person("Smith",23);
        CurrentAcc c1 = new CurrentAcc(smith,(long)(Math.random()*100000),2000);
    
        c1.deposit(2000);
        
        Person kathy = new Person("Kathy",10);
        SavingsAcc s2 = new SavingsAcc(kathy,(long)(Math.random()*100000),3000);
        
        s2.withdraw(2000);
    try{
    	if(smith.getPerAge()<15 || kathy.getPerAge()<15)
    	{
    		throw new NotValidAge("Age of a person should be above 15.");
    	}
    	else{
        System.out.println("Smith Details: "+c1);
        System.out.println("Current balance of Smith: "+ c1.getBalance());
        System.out.println("\nKathy Details: "+s2);
        System.out.println("Current balance of Kathy: "+ s2.getBalance());

        System.out.println("\nCurrent Result after withdraw of 3000.");
        c1.withdraw(3000);
        System.out.println("Smith Details: "+c1);
        System.out.println("Current balance of Smith: "+ c1.getBalance());
        
        System.out.println("\nSaving Result after withdraw of 600 from 1000 balance.");
        s2.withdraw(600);
        System.out.println("Kathy Details: "+s2);
        System.out.println("Current balance of Kathy: "+ s2.getBalance());
    	}
    }
    catch(NotValidAge ag) {
    	System.out.println("Age of a person should be above 15.");
    }
   
    }

}