//main class
public class TestInterfaceDemo {

	public static void main(String[] args) {
		Printable pp=new Box(8,9,2);
		System.out.println("Box info : ");
		pp.print();
		System.out.println("Box Volumn : "+
		((Box)pp).calcVol());
		

	}

}
