//interface classS
public interface Printable 
{
	static double PI=3.14566;
	void print();
	//by default interface functions are public and abstract
	//we can only declared static and final variable in interface

}
