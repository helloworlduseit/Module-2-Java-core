/*java 5 Features:
 * static import
 * Anotation
 * var ar
 * generics
 * Enhance for loop
 * Enum
 * */

import static java.lang.Math.*;
/*because of static import we can use keywords which \
 * are there in Math class directly*/

class Parent
{
	public void print()
	{
		System.out.println("Parent");
	}
	/*var ar feature of java5
	 * becoz of this we can give n number of inputs with different parameters
	 *  to the add function
	 * it will store the user inputs into array*/
	public int add(int ... numbers)
	{
		int sum=0;
		for(int j=0;j<numbers.length;j++)
		{
			sum=sum+numbers[j];
		}
		return sum;
	}
}

class child extends Parent
{
	@Override
	/*this Anotation will help the compiler to check whether we r doing overriding or not
	 * it will avoid the typing mistakes of user while typing name of function*/
	public void print()
	{
		System.out.println("Child");
	}
}


public class TestJava5FeatureDemo {

	public static void main(String[] args) {
		System.out.println("PI = "+PI);
		System.out.println("Cube of 2  = "+pow(2,3));
		Parent pp= new Parent();
		System.out.println("Addition :"+pp.add(1,2,3,4));
		
		
		//Enhance For Loop
		System.out.println("Enhance For Loop");
		int marks[]={90,10,80};
		String cityList[]={"Pune","Mumbai","Noida","Sahibabad"};
		
		for(int tempMarks:marks)
		{
			System.out.println(" "+tempMarks);
		}
		for(String city:cityList)
		{
			System.out.print(" "+city);
		}
	}
}
