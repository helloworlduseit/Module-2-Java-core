//main class

import java.util.Scanner;
public class TestBankAppDemo {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int currentBalance=60000;
		System.out.println("Enter the Withdraw Amount");
		int withdrawAmt=sc.nextInt();
		if(withdrawAmt<currentBalance)
		{
			System.out.println("OK U have sufficient balance U can Withdraw");
		}
		else
		{
			try {
				throw new LowBalanceException("Please chk balance of UR Account");
			} catch (LowBalanceException e) {
				System.out.println("Insufficient balance in UR account");
			}
		}	
	}
}
