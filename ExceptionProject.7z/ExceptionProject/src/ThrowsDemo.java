import java.io.IOException;
//this package is imported to handled IO exception


public class ThrowsDemo 
{
	public void method1() throws  IOException
	//here throws again tells caller to handled the exception which is passed by method2();
	{
		System.out.println("Inside method 1");
		method2();
	}
	public void method2() throws  IOException
	//this throws tells caller to handle the exception 
	{
		System.out.println("Inside method 2");
		throw new IOException();
	}
/*thowing the exception to calling method again and again and handling it in
	main is called as deligating(Propagating) the exception*/
}
