
public class TestAccount {

	public static void main(String[] args) {
		double acc=((double)Math.random()*10000);
		long accn=(long)acc;
		Person smithP= new Person("Smith",36);
		Account smith=new Account(accn,2000,smithP);
		
		double acc2=((double)Math.random()*10000);
		long accn2=(long)acc;
		Person kathyP= new Person("Kathy",23);
		Account kathy=new Account(accn2,3000,kathyP);
		
		smith.deposit(2000);
		kathy.withdraw(2000);
				
		System.out.println(smith.toString());
		System.out.println(kathy.toString());
		
		
	}

}
