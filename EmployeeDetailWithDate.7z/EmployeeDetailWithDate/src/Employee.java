
public class Employee {
	private int empId;
	private String empName;
	private float empSal;
	Date empDoj;
	public Employee() {
		empId = 0;
		empName = "Unknown";
		empSal = 0.0F;
		empDoj = new Date();
	}
	public Employee(int empId, String empName, float empSal, Date empDoj) {
		
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDoj = empDoj;
	}

	public String dispEmployeeInfo() {
		return "\nempId=" + empId + "\nempName=" + empName
				+ "\nempSal=" + empSal + "\nempDoj=" + empDoj.disDate() ;
	}
	
	
}
