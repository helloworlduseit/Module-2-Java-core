import java.util.Scanner;
import java.util.regex.*;

public class TestPattenDemo
{

	public static void main(String[] args) 
	{
		String inputStr = "Test String";
		String patern = "Test String";
		boolean patternMatched = Pattern.matches(patern, inputStr);
		System.out.println(patternMatched);

		/*
		 * Pattern pattern1 = Pattern.compile(","); String[] str =
		 * pattern1.split("Shop,Mop,Hopping,Chopping"); for (String st : str) {
		 * System.out.println(st); }
		 */
		String input = "Shop,Mop,Hopping,Chopping";
		Pattern pattern = Pattern.compile("hop");
		Matcher matcher = pattern.matcher(input);
		///System.out.println(matcher.matches());
		while (matcher.find()) {
			System.out.println(matcher.group() + ": " + matcher.start() + ": "
					+ matcher.end());
	}
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Mobile No:");
		String mobile=sc.next();
		String mobilePatter="[7-9][0-9]{9}";
		if(Pattern.matches(mobilePatter , mobile))
		{
			System.out.println("Valid mobile No");
		}
		else
		{
			System.out.println("Only 10 digits starts with 7 8 9 allowed");
		}
		
	}
}

