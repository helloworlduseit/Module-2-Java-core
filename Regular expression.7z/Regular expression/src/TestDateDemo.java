import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDateDemo 
{

	public static void main(String[] args)
	{
		LocalDate today=LocalDate.now();
		System.out.println("Today's Date :"+today);
		System.out.println("*************************************");
		LocalDate myDoj = LocalDate.of(2017, 12, 13);
		System.out.println("My Date of Joining: "+myDoj);
		System.out.println("*************************************");
		
		String ronalDoj = "03-Oct-2010";
		DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate ronalDojD = LocalDate.parse(ronalDoj, myFormat);
		System.out.println("Ronal DOJ : "+ronalDojD);
		
		/*Applying reqd format to Date*/
		DateTimeFormatter secondFormat=DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		
		String urDoj=ronalDojD.format(secondFormat);
		System.out.println("....."+urDoj);
		
		/*Date Arithmetic*/
		System.out.println("Difference");
		
		Period period=Period.between(myDoj, today);
		
		int years=period.getYears();
		int month=period.getMonths();
		int days=period.getDays();
		
		System.out.println("My Experience In CG is :"+ years+ " Years "+month+" Months "+days+ " day");
		
	}

}
