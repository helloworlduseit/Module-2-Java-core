package com.cg.mobilemgm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;
import com.cg.mobilemgm.service.MobileService;
import com.cg.mobilemgm.service.MobileServiceImpl;

public class MobileClient 
{
	static Scanner sc=null;
	static MobileService mobser=null;
	public static void main(String[] args) 
	{
		sc=new Scanner(System.in);
		mobser= new MobileServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("What Do U want to do ?");

			System.out.println("1) Insert the customer and purchase details & Update the mobile quantity\n"
					+ "2) View details of all mobiles\n"
					+ "3) Delete a mobile details Emp\n"
					+ "4) Search mobiles\n"
					+ "5) Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
			{
				insertDetail();
				break;
			}
			case 2:
			{
				selectAllMobDetails();
				break;
			}
			case 3:
			{
				deleteMobDetail();

				break;
			}
			case 4:
			{
				searchMobiles();
				break;
			}
			default:System.exit(0);

			}

		}
	}


	/////////////////////////
	public static void insertDetail()
	{
		System.out.println("Enter Customer Name: ");
		String cNm=sc.next();
		PurchaseDetails pur=null;
		Mobiles mob=null;
		try 
		{
			if(mobser.validateName(cNm))
			{
				System.out.println("Enter Customer Mail Id: ");
				String mail= sc.next();
				if(mobser.validateEmail(mail))
				{
					System.out.println("Enter Customer Phone Number: ");
					String phnNo=sc.next();
					if(mobser.validateDigit(phnNo))
					{
						System.out.println("Enter Mobile Id: ");
						int mobId= sc.nextInt();
						if(mobser.validateMobileId(mobId))
						{
							mob=new Mobiles();
							mob.setMobileId(mobId);
							System.out.println("Enter Puchased Mobile Quantity: ");
							int mobQuan=sc.nextInt();
							if(mobser.validateMobileQuan(mob)>mobQuan)
							{
								mob.setMobileQuantity(mobQuan);			
								if(mobser.updateMobile(mob)>0)
								{
									pur=new PurchaseDetails();
									pur.setCustName(cNm);
									pur.setCustEmail(mail);
									pur.setCustPhoneNo(phnNo);

									int dataAdded=mobser.addMobPur(pur,mob);

									if(dataAdded==1)
									{
										System.out.println("Purchase Data Added.");
									}
									else
									{
										System.out.println("May be Some Exception occus while Adding Data");
									}
								}

							}
							else
							{
								System.out.println("Entered Mobile Quan is less than available quantity");
							}
						}
					}
				}
			}
		} 
		catch (MobileException e)
		{
			e.printStackTrace();
		}
	}
	////////////////////////
	private static void selectAllMobDetails() 
	{
		try
		{
			ArrayList<Mobiles> mobList=mobser.getAllMob();
			for(Mobiles m:mobList)
			{
				System.out.println(m);
			}
		} 
		catch (MobileException e)
		{
			System.out.println("Some Exception occurs while fetching data");
			e.printStackTrace();
		}	

	}
	///////////////////////////////

	private static void deleteMobDetail() 
	{
		int data=0;
		System.out.println("Enter Mobile Id whose detail to be deleted: ");
		int id=sc.nextInt();
		//	Mobiles mob=new Mobiles();
		try
		{
			if(mobser.validateMobileId(id))
			{
				System.out.println("Data valid....");
				//	mob.setMobileId(id);
				data=mobser.deleteMobDetail(id);
				if(data==1)
				{
					System.out.println("Data deleted....");
				}
				else{
					System.out.println("Some Exception occurs Deleting data");
				}
			}

		}
		catch (MobileException e)
		{

			System.out.println(e.getMessage());
		}


	}

	//////////////////////////////////////////////////////

	private static void searchMobiles() {
		System.out.println("Enter Minimum range of Price: ");
		float minRange=sc.nextFloat();
		System.out.println("Enter Maximum range of Price: ");
		float maxRange=sc.nextFloat();
		try{
			if(maxRange>minRange)
			{
				ArrayList<Mobiles> mobList=mobser.searchMob(maxRange, minRange);
				for(Mobiles range:mobList)
				{
					System.out.println(range);
				}		
			}
		}
		catch (MobileException e)
		{

			System.out.println(e.getMessage());
		}

	}
}

