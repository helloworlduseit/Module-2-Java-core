import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class TestHashMapDemo {

	public static void main(String[] args) {
		HashMap<Long,String> mobileDirectly=new HashMap<Long,String>();
		mobileDirectly.put(8082246498L,"Jyoti");
		mobileDirectly.put(9865325896L,"Babitha");
		mobileDirectly.put(965478963L,"Ooha");
		mobileDirectly.put(4587963258L,"Chamu");
		mobileDirectly.put(8082246498L,"Jyoti");
		Set<Entry<Long,String>> setIt=mobileDirectly.entrySet();
		
		Iterator<Entry<Long,String>> mobIt=setIt.iterator();
		while(mobIt.hasNext())
		{
			Entry<Long,String> dirEntry=mobIt.next();
			System.out.println("Mobile: "+dirEntry.getKey()+"\tName: "+dirEntry.getValue());
		}
	}

}
