import java.util.ArrayList;
import java.util.HashSet;


public class TestEmpHashSetDemo 
{

	public static void main(String[] args)
	{
		HashSet<Emp> empSet=new HashSet<Emp>();
		/*Hashcode for e2 and e5 is different
		 * bcoz hashcode is nothing but unique references from stack
		 * This is becoz we haven't override hashcode in Emp class*/
		Emp e1=new Emp(333,"Jyoti",15.0F);
		Emp e2=new Emp(120,"Baby",4000.0F);
		Emp e3=new Emp(45,"Ooha",6541.0F);
		Emp e4=new Emp(98,"Chams",7800.0F);
		Emp e5=new Emp(120,"Baby",4000.0F);
		/*If contents are equal then only Equals operator prints the Same
		 * Here we are comparing objects of class which are there
		 * in different location in stack*/
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		System.out.println("***********Without For Loop*****************");
		System.out.println(empSet);
		System.out.println("***********With For Loop*****************");
		for(Emp tempEmp:empSet)
		{
			System.out.println(tempEmp);
		}

	}

}
