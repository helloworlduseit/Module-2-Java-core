import java.util.ArrayList;
import java.util.Iterator;


public class TestEmpArrayListDemo {

	public static void main(String[] args) {
		ArrayList<Emp> empList=new ArrayList<Emp>();
		
	Emp e1=new Emp(333,"Jyoti",4000.0F);
	Emp e2=new Emp(333,"Baby",4000.0F);
	Emp e3=new Emp(333,"Ooha",4000.0F);
	Emp e4=new Emp(333,"Chams",4000.0F);
	Emp e5=new Emp(333,"Kritika",4000.0F);
	
	empList.add(e1);
	empList.add(e2);
	empList.add(e3);
	empList.add(e4);
	empList.add(e5);
	System.out.println("***********Without Iterator*****************");
	System.out.println(empList);
	System.out.println("**********With Iterator*********************");
	
	Iterator<Emp> empListIt=empList.iterator();
	while(empListIt.hasNext())
	{
		Emp tempEmp=empListIt.next();
		System.out.print("ID :"+tempEmp.getEmpId());
		System.out.print("\tName :"+tempEmp.getEmpName());
		System.out.print("\tSalary :"+tempEmp.getEmpSal());
		
		System.out.println("\n---------------------------");
	}

	}

}
