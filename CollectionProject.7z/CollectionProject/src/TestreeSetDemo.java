	import java.util.HashSet;
import java.util.HashSet;
import java.util.TreeSet;
public class TestreeSetDemo {




		public static void main(String[] args) {
			TreeSet<Integer> intSet= new TreeSet<Integer>();
			/*HashSet--->Unique and Random Output*/
			Integer i1=new Integer(10);
			Integer i2=new Integer(5);
			Integer i3=new Integer(20);
			Integer i4=new Integer(34);
			Integer i5=new Integer(5);
			
			intSet.add(i1);
			intSet.add(i2);
			intSet.add(i3);
			intSet.add(i4);
			intSet.add(i5);
			System.out.println("***********Without Iterator*****************");
			System.out.println(intSet);

		}




}
