import java.util.ArrayList;
import java.util.TreeSet;
public class TestTreeSetEmpDemo 
{
		public static void main(String[] args)
		{
			TreeSet<Emp> empSet=new TreeSet<Emp>();
			
			Emp e1=new Emp(333,"Jyoti",15.0F);
			Emp e2=new Emp(120,"Baby",4000.0F);
			Emp e3=new Emp(45,"Ooha",6541.0F);
			Emp e4=new Emp(98,"Chams",7800.0F);
			Emp e5=new Emp(120,"Baby",4000.0F);
			
			empSet.add(e1);
			empSet.add(e2);
			empSet.add(e3);
			empSet.add(e4);
			empSet.add(e5);
			System.out.println("***********Without For Loop*****************");
			System.out.println(empSet);
			System.out.println("***********With For Loop*****************");
			for(Emp tempEmp:empSet)
			{
				System.out.println(tempEmp);
			}

		}

	

}
