import java.util.ArrayList;
import java.util.*;


public class TestIntArrayListDemo
{

	public static void main(String[] args) 
	{
		/*This Generic feacture given by java5
		 * we can directly*/
		ArrayList<Integer> intList=new ArrayList<Integer>();
		/*Colection works on objects,
		 * not on Primitive data type so firstly we have to
		 * convet primitive datatypes into object
		 * Here we convert int into Integer Object*/
		Integer i1=new Integer(10);
		Integer i2=new Integer(5);
		//String str3=new String("Capgemini");
		Integer i3=new Integer(20);
		Integer i4=new Integer(34);
		Integer i5=new Integer(5);
		
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		intList.add(i5);
		System.out.println("*****************Without Iterator********************");
		System.out.println(intList);
		System.out.println("*****************With Iterator***********************");
		
		Iterator<Integer> it=intList.iterator();
		while(it.hasNext())
		{
			Integer tempEntry=it.next();
			System.out.println("  "+tempEntry);
		}
	}

}
