import java.util.Scanner;
public class InheritMedi {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("How many Medicines u want?");
		int mediCount=sc.nextInt();
		String mName, nComName;
		int mPrice,day,month,year;
		Medicine mediArr[]=new Medicine[mediCount];
		int choice;
		Date date;
		for(int i=0;i<mediCount;i++)
		{
			System.out.println("What Type of Medicine You Want?\n"
					+ "1: Tablet\t2: Oinment\t3: Syrup");
			System.out.println("Enter Choice");
			choice=sc.nextInt();
			System.out.println("Enter Medicine "+(i+1)+" Name: ");
			mName=sc.next();
			System.out.println("Enter Medicine company "+(i+1)+" Name: ");
			nComName=sc.next();
			System.out.println("Enter Medicine Expiry Date : ");
			day=sc.nextInt();
			month=sc.nextInt();
			year=sc.nextInt();
			date=new Date(day,month,year);
			System.out.println("Enter Medicine Price : ");
			mPrice=sc.nextInt();
			switch(choice)
			{
			case 1:
				mediArr[i]=new Tablet(mName,nComName,date,mPrice);
				break;
				
			case 2:
				mediArr[i]=new Oinment(mName,nComName,date,mPrice);
				break;
				
			default:
				mediArr[i]=new Syrup(mName,nComName,date,mPrice);
				break;
			}
			}
		System.out.println("**************************************************");
		for(int i=0;i<mediCount;i++)
		{
			if(mediArr[i] instanceof Tablet)
			{
				System.out.println("\nTablet Information : "+mediArr[i].dispMediInfo());
			}
			else if(mediArr[i] instanceof Oinment)
			{
				System.out.println("\nOinment Information : "+mediArr[i].dispMediInfo());
			}
			else
			{
				System.out.println("Syrup Information : "+mediArr[i].dispMediInfo());
			}
		}
	
	}

}

