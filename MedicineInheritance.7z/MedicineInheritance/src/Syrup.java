
public class Syrup extends Medicine {

	public Syrup() {
		super();
		
	}

	public Syrup(String mediName, String mediCompany, Date date,
			int price) {
		super(mediName, mediCompany, date, price);
		
	}
	public String dispMediInfo() {
		return super.dispMediInfo()+ "\nShake well before used";
	}


	
}
