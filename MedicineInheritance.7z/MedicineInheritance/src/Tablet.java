
public class Tablet extends Medicine {

	public Tablet() {
		
	}

	public Tablet(String mediName, String mediCompany, Date date,
			int price) {
		super(mediName, mediCompany, date, price);
		
	}
	public String dispMediInfo() {
		return super.dispMediInfo()+ "\nStore in cool and dry place";
	}

}
