public class Medicine {
	private String mediName;
	private String mediCompany;
	//private String mediExpdate;
	private int price;
	Date date;
	public Medicine() {
		
	}
	public Medicine(String mediName, String mediCompany, Date date,
			int price) {
		super();
		this.mediName = mediName;
		this.mediCompany = mediCompany;
		this.date = date;
		this.price = price;
	}

	public String dispMediInfo() {
		return "MediName=" + mediName + "\nmediCompany="
				+ mediCompany + "\nmediExpdate=" + date.dispDate() + "\nprice="
				+ price;
	}
	
	
}
