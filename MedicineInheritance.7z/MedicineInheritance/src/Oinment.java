
public class Oinment extends Medicine {

	public Oinment() {	}

	public Oinment(String mediName, String mediCompany, Date date,
			int price) {
		super(mediName, mediCompany, date, price);
		
	}
	public String dispMediInfo() {
		return super.dispMediInfo()+ "\nExternal use only";
	

}
}
