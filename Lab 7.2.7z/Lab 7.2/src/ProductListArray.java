import java.util.ArrayList;

import java.util.Collections;



public class ProductListArray {

	public static void main(String[] args) {
		ArrayList<String> productSet=new ArrayList<String>();
		
		String i1=new String("Detol");
		String i2=new String("Ponds");
		String i3=new String("Syntol");
		String i4=new String("Bottol");
		String i5=new String("Handwash");
		
		productSet.add(i1);
		productSet.add(i2);
		productSet.add(i3);
		productSet.add(i4);
		productSet.add(i5);
		
		System.out.println("***********Before Sorting****************");
		System.out.println(productSet);
		Collections.sort(productSet);
		System.out.println("***********With For Loop*****************");
		
		for(String tempSet:productSet)
		{
			System.out.println(tempSet);
		}
		
	}

}
