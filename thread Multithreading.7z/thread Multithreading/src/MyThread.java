
public class MyThread implements Runnable//extends Thread
{
	String msg;
	public MyThread(String msg)
	{
		this.msg=msg;
	}
	@Override
	public void run()
	{
		Thread cueeThread=Thread.currentThread();
		if(cueeThread==TestSleepDemo.t2)
		{
			try {
				TestSleepDemo.t1.join();
			} 
			catch (InterruptedException e) 
			{

				e.printStackTrace();
			}
		}
		for(int j=0;j<3;j++){
			System.out.println(cueeThread.getName()+" Says : "+msg);
			try {
				Thread.sleep(500);
			} 
			catch (InterruptedException e) 
			{

				e.printStackTrace();
			}
		
	}
}


}
