package com.cg.eis.exception;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.InsuranceService;

public class TestExceptionEmployee {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int eId;
		String eName;
		double eSalary;
		String eDesignation;
		System.out.println("Enter Employee Id:");
		eId=sc.nextInt();
		System.out.println("Enter Employee Name:");
		eName=sc.next();
		System.out.println("Enter Employee Salary: ");
		eSalary=sc.nextDouble();
		System.out.println("Enter Employee Designation:");
		eDesignation=sc.next();
		try{
			
			if(eSalary<3000)
			{
				throw new EmployeeException();
			}
			else{
			InsuranceService ser = new InsuranceService(eSalary,eDesignation);
			String isc=ser.getInsuranceScheme();
			Employee emp= new Employee(eId,eName,eSalary,eDesignation,isc);
			System.out.println(emp.dispEmp());
			}

		}
		catch(EmployeeException ee)
		{
			System.out.println("Plz entered salary more than 3000");
		}

	}
	}

