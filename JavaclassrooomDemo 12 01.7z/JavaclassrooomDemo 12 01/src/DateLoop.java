import java.util.Scanner;
public class DateLoop {

	public static void main(String[] args) {
		Scanner sc	=	new Scanner(System.in);
		
		Date allDojs[]	=	new Date[3];
		String names[]=new String[3];
		int day=0,mon=0,year=0;
		
		for(int i=0;i<allDojs.length;i++){
			System.out.println("Enter your Name: ");
			names[i]	=	sc.next();
			System.out.println("Enter your Day: ");
			day	=	sc.nextInt();
			System.out.println("Enter your Month of joining: ");
			mon	=	sc.nextInt();
			System.out.println("Enter your Year: ");
			year	=	sc.nextInt();
			
			allDojs[i]=new Date(day,mon,year);
		}
		
		for(int i=0;i<allDojs.length;i++){
			System.out.println(names[i]+" DOJ : "+allDojs[i].dispDate());
		}
	}
}
