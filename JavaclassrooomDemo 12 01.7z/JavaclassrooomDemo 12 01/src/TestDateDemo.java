import java.util.Scanner;
public class TestDateDemo {

	public static void main(String[] args) {
		Scanner sc	=	new Scanner(System.in);
		
		System.out.println("Enter Day : ");
		int dayOfDoj	=	sc.nextInt();
		
		System.out.println("Enter Month : ");
		int monOfDoj	=	sc.nextInt();
		
		System.out.println("Enter Year : ");
		int yearOfDoj	=	sc.nextInt();
		
		
		
		System.out.println("Enter Day : ");
		int dayOfDoj2	=	sc.nextInt();
		
		System.out.println("Enter Month : ");
		int monOfDoj2	=	sc.nextInt();
		
		System.out.println("Enter Year : ");
		int yearOfDoj2	=	sc.nextInt();
		
		Date jyotiDOJ	=	new Date(dayOfDoj, monOfDoj, yearOfDoj );
		System.out.println( "Your DOJ : "+jyotiDOJ.dispDate());
		Date BabzDOJ	=	new Date(dayOfDoj2, monOfDoj2, yearOfDoj2 );
		System.out.println( "Your DOJ : "+BabzDOJ.dispDate());
	}

}
