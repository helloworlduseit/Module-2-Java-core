
public class Person 
{
	private String perName;
	private String panNo;
	private int personAge;
	//getter setter function
	public String getPerName() {
		return perName;
	}
	public void setPerName(String perName) {
		this.perName = perName;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public int getPersonAge() {
		return personAge;
	}
	public void setPersonAge(int personAge) {
		this.personAge = personAge;
	}
	//constructors
	public Person() {
		
	}
	public Person(String perName, String panNo, int personAge) {
		
		this.perName = perName;
		this.panNo = panNo;
		this.personAge = personAge;
	}
	@Override
	public String toString() {
		return "Person [perName=" + perName + ", panNo=" + panNo
				+ ", personAge=" + personAge + "]";
	}
	@Override
	public int hashCode() {
		int result;
		result = ((panNo == null) ? 0 : panNo.hashCode());
		return result;
	}
	
	@Override
	//.equal() inbuilt function we are overriding so that comparison 
	//of objects is done based on panNo
	public boolean equals(Object obj) {
		Person tempPerson=(Person)obj;
		if(this.panNo==tempPerson.panNo)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	

	


}
