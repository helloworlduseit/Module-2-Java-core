package com.cg.stu;
import com.cg.bat.Batch;

public class Student {
	private int rollNo;
	private String stuName;
	private float stuMark;
	private Batch stuBatch;
	public Student() {
		
	}
	public Student(int rollNo, String stuName, float stuMark, Batch stuBatch) {
		
		this.rollNo = rollNo;
		this.stuName = stuName;
		this.stuMark = stuMark;
		this.stuBatch = stuBatch;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public float getStuMark() {
		return stuMark;
	}
	public void setStuMark(float stuMark) {
		this.stuMark = stuMark;
	}
	public Batch getStuBatch() {
		return stuBatch;
	}
	public void setStuBatch(Batch stuBatch) {
		this.stuBatch = stuBatch;
	}

	public String dispStuInfo() {
		return "Student [rollNo=" + rollNo + ", stuName=" + stuName
				+ ", stuMark=" + stuMark + ", stuBatch=" + stuBatch.showBatchInfo() + "]";
	}
	

	}
	
	

