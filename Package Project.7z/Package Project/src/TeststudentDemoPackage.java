import com.cg.bat.Batch;
import com.cg.stu.Student;
public class TeststudentDemoPackage {

	public static void main(String[] args) {
		Batch javaBatch=new Batch("JEE_Propel_001","8.30 TO 6.00","Anjulata Tembhare");
		Batch oraAppBatch=new Batch("Ora app_ABridge_003","9.00 TO 6.00","Sachin Naradekar");
		
		Student student1 = new Student(11,"Ronak",90,javaBatch);
		Student student2 = new Student(12,"Vaibhav",56,javaBatch);
		Student student3 = new Student(13,"Nilima",70,oraAppBatch);
		Student student4 = new Student(14,"Devangana",55,oraAppBatch);
		
		System.out.println(student1.dispStuInfo());
		System.out.println(student2.dispStuInfo());
		System.out.println(student3.dispStuInfo());
		System.out.println(student4.dispStuInfo());
		
	}

}
