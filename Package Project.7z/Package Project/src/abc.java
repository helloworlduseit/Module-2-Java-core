
public class abc {
	public static void main(String[] args) {
	double t=(double)Math.random()*10000;
	long acc=(long)t;
	System.out.println(t);
	System.out.println(acc);

}
}
