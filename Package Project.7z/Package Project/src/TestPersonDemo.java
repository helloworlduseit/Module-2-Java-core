
public class TestPersonDemo {

	public static void main(String[] args) 
	{
		Person p1=new Person("Vaishali S", "CBH78GOP",10);
		Person p2=new Person("Babitha N", "C0VP0040",13);
		Person p3=new Person("Vaishali S", "CBH78GOP",10);
		
		System.out.println(p1);//here we override the toString() so that 
		//instead of memory reference directly data is called by object
		System.out.println(p2);
		System.out.println(p3);
		
		/*if(p1==p3)
		{
			System.out.println("Same");
		}
		else
		{
			System.out.println("Not Same");
		}*/
		//we should no use == sign for comparing objects
		
		if(p1.equals(p3))
		{
			System.out.println("Same");
		}
		else
		{
			System.out.println("Not Same");
		}
//above code gives false in output bcoz .equal() operator 
//compares references of  objects. In this case data is same but reference is different
//So output is "Not same".
		
//To do this we override equal() function in Person class based on panNo comparison
	
		Integer i1=new Integer(20);
		Integer i2=new Integer(30);
		Integer i3=new Integer(20);
		//the value of i1,i2,i3 directly printed as toString function is already overridden
		System.out.println("i1= "+i1);
		System.out.println("i1= "+i2);
		System.out.println("i1= "+i3);
		//in java for every class toString() is already overridden wherever data is present
		if(i1.equals(i2))
		{
			System.out.println("Hey we are Same");
		}
		else
		{
			System.out.println("Hey we are not Same");
		}
		
		System.out.println("Hashcode of p1 "+p1.hashCode());//generate unique integer for every object
		System.out.println("Hashcode of p2 "+p2.hashCode());///hashcode having integer return type
		System.out.println("Hashcode of p3 "+p3.hashCode());
		System.out.println("Hashcode of i1 "+i1.hashCode());
		System.out.println("Hashcode of i2 "+i2.hashCode());
		System.out.println("Hashcode of i3 "+i3.hashCode());
	}

}
