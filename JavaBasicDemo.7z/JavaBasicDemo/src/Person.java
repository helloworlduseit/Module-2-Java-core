
public class Person {
	private String firstName;
	private String lastName;
	private char gender;
	private int age; 
	private float weight;

public Person(String fName, String lName, char gen, int pAge, float pWeight){
	firstName	=	fName;
	lastName	=	lName;
	gender		=	gen;
	age			=	pAge;
	weight		=	pWeight;
}
public void dispPerson(){
	System.out.println("Person Details:");
	System.out.println("------------------------------");
	System.out.println("First Name: "+firstName);
	System.out.println("Last Name: "+lastName);
	System.out.println("Gender: "+gender);
	System.out.println("Age: "+age);
	System.out.println("Weight: "+weight);
}
public static void main(String[] args) {
	Person testPerson = new Person("Divya", "Bharathi", 'F', 20, 85.55F);
	testPerson.dispPerson();

}
}