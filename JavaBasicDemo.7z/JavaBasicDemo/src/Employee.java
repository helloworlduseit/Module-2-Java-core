
public class Employee {

	public static void main(String[] args) {
		Emp jyoti = new Emp(12,"Jyoti",1212,'F');
		System.out.println("Employee Detail: ");
		jyoti.dispEmployee();
		
		Emp babz = new Emp(142884,"Babitha",9635,'F');
		babz.dispEmployee();
		
		Emp unknownPerson = new Emp();
		unknownPerson.dispEmployee();
	}

}
