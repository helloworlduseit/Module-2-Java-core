
public class TestStudentBeanDemo {

	public static void main(String[] args) {
		Student s1	=	new Student();
		s1.setRollNo(12);
		s1.setMark(111);
		s1.setStuName("Jyoti");
		
		System.out.println("Name: "+s1.getRollNo());
		System.out.println("Mark: "+s1.getMark());
		System.out.println("Name: "+s1.getStuName());
		

	}

}
