
public class TestDateDemo {

	public static void main(String[] args) {
		Date jyotiDOJ	=	new Date(13, 12, 2017);
		System.out.println("Jyoti DOJ is:	"+jyotiDOJ.dispDate());
		
		Date vaiDOJ	=	new Date(03, 04, 2013);
		System.out.println("Vaishali DOJ is	:	"+vaiDOJ.dispDate());
		
		Date unknownPerson	=	new Date();
		
		System.out.println("Unknown personDOJ is:	"+unknownPerson.dispDate());
	}

}
