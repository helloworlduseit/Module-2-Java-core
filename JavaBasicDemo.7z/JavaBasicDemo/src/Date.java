public class Date {
	private int day;
	private int month;
	private int year;
	
	public Date()
	{
		day		=	0;
		month	=	0;
		year	=	0;	
		
	}
	public Date(int dd,int mm,int yy)
	{
		day		=	dd;
		month	=	mm;
		year	=	yy;
	}
	public String dispDate()
	{
		return day+"-"+month+"-"+year;
	}
}
