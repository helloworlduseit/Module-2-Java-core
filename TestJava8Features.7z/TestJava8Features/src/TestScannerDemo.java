import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

@FunctionalInterface
interface MaxFiner 
{
public int max(int num1,int num2);
}
public class TestScannerDemo
{
	public static void main(String[] args)
	{
		try(Scanner sc=new Scanner(System.in))
		{
			/*MaxFiner mf=(num1,num2)->num1>num2?num1:num2;
			System.out.println("Greatet no is: "+mf.max(90, 80));*/
			
			
			Consumer<String> consumer=(String str)->System.out.println(str);
			consumer.accept("Welcome");
			
			Supplier<String> sup=()->"Happy New Year";
			System.out.println(sup.get());
			
			BiFunction<Integer, Integer, Integer> biFunctiona=(x,y)-> x>y?x:y;
			System.out.println("Greatest Number is: "+biFunctiona.apply(90,80));
			
			Predicate<Integer> predicate=(num)->num%2==0;
			System.out.println("Is 4 Even No:"+predicate.test(4));
			System.out.println("Is 3 Even No:"+predicate.test(3));

		}
	}
}
