import java.util.Scanner;
public class TestInheritanceEmpArray {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("How many Employees?");
		int empCount=sc.nextInt();
		Employee empArr[]=new Employee[empCount];
		int eId=0,choice;
		int noOfHrs=0,ratePerHrs=0;
		String enm=null;
		float esl=0.0f;
		for(int i=0;i<empArr.length;i++)
		{
			System.out.println("What Type of Emp You Want?\n"
					+ "1: Emp\t2: WageEmp\t3: SalesMgr");
			System.out.println("Enter Choice");
			choice=sc.nextInt();
			System.out.println("Enter Emp "+(i+1)+" Id: ");
			eId=sc.nextInt();
			System.out.println("Enter Emp "+(i+1)+" Name: ");
			enm=sc.next();
			System.out.println("Enter Emp "+(i+1)+" Salary: ");
			esl=sc.nextFloat();
		
			switch(choice)
			{
			case 1:empArr[i]= new Employee(eId,enm,esl);
					break;
			
			case 2:System.out.println("Enter No of Hrs you worked:");
					noOfHrs=sc.nextInt();
					System.out.println("Enter Rate per Hour:");
					ratePerHrs=sc.nextInt();
					empArr[i]=new WageEmp(eId,enm,esl,noOfHrs,ratePerHrs);
					break;
					
			default:
				System.out.println("Enter No of Hrs you worked:");
				noOfHrs=sc.nextInt();
				System.out.println("Enter Rate per Hour:");
				ratePerHrs=sc.nextInt();
				System.out.println("Enter Sales You have done ");
				int sale=sc.nextInt();
				System.out.println("Enter Commission you Got: ");
				float comm=sc.nextFloat();
				empArr[i]=new SalesManger(eId,enm,esl,noOfHrs,ratePerHrs,sale,comm);
				break;
			}				
			
		}
		System.out.println("**************************************************");
		for(int i=0;i<empCount;i++)
		{
			if(empArr[i] instanceof SalesManger)
			{
			System.out.println("Sales Manger: "+(i+1)+" Information:"+empArr[i].dispEmpInfo()+
			"\nEmp "+(i+1)+" Monthly Basic Salary : "+empArr[i].calcEmpBasicSal()+
			"\nEmp "+(i+1)+" Annual Salary :"+empArr[i].calcEmpAnnualSal());
			}
			else if(empArr[i] instanceof WageEmp)
			{
				System.out.println("Wage Employee: "+(i+1)+" Information:"+empArr[i].dispEmpInfo()+
						"\nEmp "+(i+1)+" Monthly Basic Salary : "+empArr[i].calcEmpBasicSal()+
						"\nEmp "+(i+1)+" Annual Salary :"+empArr[i].calcEmpAnnualSal());
			}
			else
			{
				System.out.println("Employee: "+(i+1)+" Information:"+empArr[i].dispEmpInfo()+
						"\nEmp "+(i+1)+" Monthly Basic Salary : "+empArr[i].calcEmpBasicSal()+
						"\nEmp "+(i+1)+" Annual Salary :"+empArr[i].calcEmpAnnualSal());
			}
		}
	}

}
