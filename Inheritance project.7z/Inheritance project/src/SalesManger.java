//grandchild class
public class SalesManger extends WageEmp 
{
	private int noOfSales;
	private float commission=0.02F;
	public SalesManger() {		
	}
	public SalesManger(int empId, String empName, float empSal, int noOfHrs,
			int ratePerHrs,int noOfSales, float commission) {
		super(empId, empName, empSal, noOfHrs, ratePerHrs);
		this.noOfSales = noOfSales;
		this.commission = commission;
	}
	public float calcEmpBasicSal()
	{
		return super.calcEmpBasicSal()+(noOfSales*commission*super.calcEmpBasicSal());
		//super will indicate immediate above parent and that parent super calles theeir parent
		
	}
	public float calcEmpAnnualSal()
	{
		return calcEmpBasicSal()*12;
	}
	
	
}
