//MAIN CLASS//
public class TestInheritanceDemo {

	public static void main(String[] args) {
		
		Employee vaishali=new Employee(111," Vaishali S",20000.0F);
		WageEmp babitha=new WageEmp(112," Babitha N",5000.0F,400,5);
		
		//In function overidding based on object creation function gets called
		System.out.println("Emp Information:\n"+vaishali.dispEmpInfo());
		System.out.println("Emp Monthly Salary : "+vaishali.calcEmpBasicSal());
		System.out.println("Emp Annual Salary :"+vaishali.calcEmpAnnualSal());
		
		System.out.println("\nEmp Information :"+babitha.dispEmpInfo());
		System.out.println("Emp Monthly Salary : "+babitha.calcEmpBasicSal());
		System.out.println("Emp Annual Salary :"+babitha.calcEmpBasicSal());
		System.out.println();
		
		Employee krittika=new WageEmp(444,"Kritikka",5000.0F,7,500);
		//This is bcoz every WageEmp is Employee
		//but remember every Emloyee is not WageEmp
		System.out.println("\nWage Emp Information :"+krittika.dispEmpInfo());
		System.out.println("Wage Emp Monthly Salary : "+krittika.calcEmpBasicSal());
		System.out.println("Wage Emp Annual Salary :"+krittika.calcEmpBasicSal());
		
		SalesManger ooha=new SalesManger(000,"Ooha",1000,7,500,10,0.2F);
		System.out.println("\nSales Manger Information :"+ooha.dispEmpInfo());
		System.out.println("Sales Manger Monthly Salary : "+ooha.calcEmpBasicSal());
		System.out.println("Sales Manger Annual Salary :"+ooha.calcEmpBasicSal());
	}

}
