public class Emp {
	private int empId;
	private String empName;
	private float salary;
	private char gender; 

	public Emp (){
		empId	=	0;
		empName	=	"unknown";
		salary	=	0;
		gender	=	' ';
	}
	public Emp(int empId, String empName, float salary, char gender){
		this.empId	=	empId;
		this.empName	=	empName;
		this.salary	=	salary;
		this.gender	=	gender;
	}
	public String dispEmployee(){
		return "\nEmployee ID: "+empId+"\n Employee Name: "+ empName+"\nEmployee Salary: "+salary+"\nEmployee Gender: "+gender;
	}
	
}
