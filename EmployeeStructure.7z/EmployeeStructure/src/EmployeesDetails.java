import java.util.Scanner;

public class EmployeesDetails {
	public static void main(String[] args) {
		Scanner sc	=	new Scanner(System.in);
		
		System.out.println("Enter the Number of employees: ");
		int count = sc.nextInt();
		
		Emp employee[]	=	new Emp[count];
		int id=0;
		float empSal=0;
		char empGen=' ';
		String empName="null";
		String tempGender = "null";
		
		for(int i=0;i<employee.length;i++){
			System.out.println("Enter your Emp ID: ");
			id	=	sc.nextInt();
			System.out.println("Enter your Name: ");
			empName	=	sc.next();
			System.out.println("Enter your Salary: ");
			empSal	=	sc.nextFloat();
			System.out.println("Enter your Gender: ");
			tempGender=sc.next();
			empGen	= tempGender.charAt(0);			
			employee[i]=new Emp(id,empName,empSal,empGen);
		}
		
		for(int i=0;i<employee.length;i++){
			System.out.println("Employee "+(i+1)+" Detail is : "+employee[i].dispEmployee());
		}
	}
}
