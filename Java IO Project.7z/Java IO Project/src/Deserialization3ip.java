	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectInputStream;
	import java.io.ObjectOutputStream;
public class Deserialization3ip {		
		public static void main(String[] args) 
			{	
			Emp ee[]=new Emp[3];
			FileInputStream fis;
			
				
				
				try {
					fis=new FileInputStream("EmpData.obj");
					ObjectInputStream oos=new ObjectInputStream(fis);
					for(int i=0;i<3;i++){
					 ee[i]=(Emp)oos.readObject();
					System.out.println("Emp Object is read from File"+ee[i]);
					}
				}  
				catch (IOException | ClassNotFoundException e) 
				{				
					e.printStackTrace();
				}
			
		
				
		}



}
