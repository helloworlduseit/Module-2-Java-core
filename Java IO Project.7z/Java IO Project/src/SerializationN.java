	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectOutputStream;
	import java.util.Scanner;

public class SerializationN {


		public static void main(String[] args) 
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter No of Emp: ");
			int count=sc.nextInt();
			Emp e[]=new Emp[count];
		for(int i=0;i<count;i++)
		{
			System.out.println("Enter Emp Id : ");
			int empId=sc.nextInt();
			
			System.out.println("Enter Emp Name: ");
			String empName=sc.next();
			
			System.out.println("Enter Emp Salary: ");
			float empSal=sc.nextFloat();
			
			e[i]=new Emp(empId,empName,empSal);
		}	
			FileOutputStream fos;
			
			try {
				fos=new FileOutputStream("newEmpData.txt");
				ObjectOutputStream oos=new ObjectOutputStream(fos);
				for(int i=0;i<count;i++){
				oos.writeObject(e[i]);
				}
				
			} catch (IOException ee) {
				
				ee.printStackTrace();
			}
			System.out.println("Emp Object is Written in a File");
		}
		
	
}



