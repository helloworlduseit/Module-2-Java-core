import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestFileDeserialization {
	
	public static void main(String[] args) 
		{	
		
			FileInputStream fis;
			
			try {
				fis=new FileInputStream("EmpData.obj");
				ObjectInputStream oos=new ObjectInputStream(fis);
				Emp ee=(Emp)oos.readObject();
				System.out.println("Emp Object is read from File"+ee);
			}  
			catch (IOException | ClassNotFoundException e) 
			{				
				e.printStackTrace();
			}
			
			
			
	}
}
