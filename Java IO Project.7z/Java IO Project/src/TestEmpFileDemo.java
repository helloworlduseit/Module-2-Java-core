import java.io.*;
public class TestEmpFileDemo {
	public static void main(String[] args) 
	{
		try {
		InputStreamReader isr=new InputStreamReader(System.in);
		
		BufferedReader br = new BufferedReader(isr);
		
		System.out.println("Enter Emp ID");
		
		int eid=Integer.parseInt(br.readLine());
		
		System.out.println("Enter Your Name: ");
		String enm=br.readLine();
		
		System.out.println("Enter emp Salary: ");
		float esl=Float.parseFloat(br.readLine());
		
		System.out.println(eid+" "+enm+ " "+esl);
		
		//writing the data into file
		
		FileWriter fw=new FileWriter("EmpInfo.txt");
		BufferedWriter bw= new BufferedWriter(fw);
		
		Integer eIdS = new Integer(eid);
		//boxing--converting primitive type into object like Integer etc.
		Float eslS=new Float(esl);
		bw.write("Emp ID: "+eIdS.toString());
		bw.newLine();
		bw.write("Emp Name: "+enm);
		bw.newLine();
		bw.write("Emp Salary: "+eslS.toString());
		bw.flush();
		System.out.println("Emp Info Written in a file");
		} 
		catch (NumberFormatException  | IOException e) {
			
			e.printStackTrace();
		} 
	}
}

