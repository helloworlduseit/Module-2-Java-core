import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class TestPropertyFileDemo 
{
	public static void main(String[] args) 
	{
		FileReader fr=null;
		Properties props=null;
		try 
		{
			fr = new FileReader("userInfo.properties");
			props=new Properties();
			props.load(fr);
			System.out.println("***************************All Data**************************");
			
			String unm=props.getProperty("username");
			String pwd=props.getProperty("Password");
			String location=props.getProperty("Location");
			String state=props.getProperty("State");
			
			System.out.println("User Name: "+unm);
			System.out.println("Password: "+pwd);
			System.out.println("Location: "+location);
			System.out.println("State: "+state);
		
			
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}

}
